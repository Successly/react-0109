export default {
    SERVER_PATH:'127.0.0.1',
    PORT:'3008',
    HTTP:'http://',
    VERSION:'1.0.0'
}