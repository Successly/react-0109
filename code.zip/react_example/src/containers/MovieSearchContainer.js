/*
 * 搜索容器组件
 * */
import React from 'react'

export default class MovieSearchContainer extends React.Component {
    constructor(props) {
        super(props)
        this.state = {

        }
    }

    render() {
        return (
           <div>
               这是搜索容器组件
           </div>
        );
    }
}

