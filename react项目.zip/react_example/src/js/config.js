export default {
    SERVER_PATH:'123.56.7.88',
    PORT:'3008',
    HTTP:'http://',
    VERSION:'1.0.0'
}