/*
* 路由配置文件
* */
import React from 'react'
import { Router, Route,IndexRoute,Redirect,browserHistory} from 'react-router'

import AppContainer from '../containers/AppContainer.js'
import HomeContainer from '../containers/HomeContainer.js'
// import MovieContainer from '../containers/MovieContainer.js'
// import MovieListContainer from '../containers/MovieListContainer.js'
// import MovieDetailContainer from '../containers/MovieDetailContainer.js'
// import MovieSearchContainer from '../containers/movieSearchContainer.js'
// import AboutContainer from '../containers/AboutContainer.js'

export default class Routers extends React.Component {
    constructor(props) {
        super(props)
        this.state = {

        }
    }

    render() {
        return (
            <Router history={browserHistory}>
                <Route path="/" component={AppContainer}>
                    <IndexRoute component={HomeContainer}/>
                    <Route path="home" component={HomeContainer} />
                    <Route path="movie"
                           getComponent={
                               (nextState, callback)=> {
                                   require.ensure([], (require)=> {
                                       callback(null, require("../containers/MovieContainer.js").default)
                                   }, "movie")
                               }
                           }
                           onEnter={()=>false}
                           onLeave={()=>false}
                    >
                        <IndexRoute getComponent={
                            (nextState, callback)=> {
                                require.ensure([], (require)=> {
                                    callback(null, require("../containers/MovieListContainer.js").default)
                                }, "movieList")
                            }
                        }

                        />
                        {/*绝对路由*/}
                        <Route path="movieList/:movieType"
                               getComponent={
                                   (nextState, callback)=> {
                                       require.ensure([], (require)=> {
                                           callback(null, require("../containers/MovieListContainer.js").default)
                                       }, "movieList")
                                   }
                               }
                        />
                        <Route path="movieDetail/:id"
                               getComponent={
                                   (nextState, callback)=> {
                                       require.ensure([], (require)=> {
                                           callback(null, require("../containers/MovieDetailContainer.js").default)
                                       }, "movieDetail")
                                   }
                               }
                        />
                        <Route path="movieSearch/:keyword"
                               getComponent={
                                   (nextState, callback)=> {
                                       require.ensure([], (require)=> {
                                           callback(null, require("../containers/MovieSearchContainer.js").default)
                                       }, "movieSearch")
                                   }
                               }
                        />
                        {/*<Redirect from="movieList" to="/movieList" />*/}
                        {/*<Redirect from="movieDetail" to="/movieDetail" />*/}
                    </Route>
                    <Route path="about"
                           getComponent={
                               (nextState, callback)=> {
                                   require.ensure([], (require)=> {
                                       callback(null, require("../containers/AboutContainer.js").default)
                                   }, "about")
                               }
                           }
                    />
                </Route>
            </Router>
        );
    }
}

