/*
 * 电影容器组件
 * */
import React from 'react'
import {Link} from 'react-router'

import '../styles/movie.css'

export default class MovieContainer extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            movieType:"in_theaters",
            keyword:''
        }
    }

    static contextTypes={
        router:React.PropTypes.object
    }

    // 改变电影类别
    changeMovieType=(movieType)=>{
        this.setState({
            movieType:movieType
        })
    }

    changeKeyWord=(e)=>{
        this.setState({
           keyword:e.target.value
        })
    }

    goSearch=()=>{
        this.context.router.push(`/movie/movieSearch/${this.state.keyword}`)
        this.setState({
            keyword:'',
            movieType:''
        })
    }

    render() {
        return (
           <div className="movie_container">
               <div className="movie_menu">
                   <Link className={this.state.movieType=='in_theaters'?'movie_current':''} to="/movie/movieList/in_theaters" onClick={()=>this.changeMovieType('in_theaters')}>正在热映</Link>
                   <Link className={this.state.movieType=='coming_soon'?'movie_current':''} to="/movie/movieList/coming_soon" onClick={()=>this.changeMovieType('coming_soon')}>即将上映</Link>
                   <Link className={this.state.movieType=='top250'?'movie_current':''} to="/movie/movieList/top250" onClick={()=>this.changeMovieType('top250')}>Top250</Link>
               </div>
               <div className="movie_right">
                   <div className="movie_search">
                       <input type="text" value={this.state.keyword} onChange={this.changeKeyWord}/>
                       <button onClick={this.goSearch}>搜索</button>
                   </div>
                   <div className="movie_content">
                       {this.props.children}
                   </div>
               </div>
           </div>
        );
    }
}

