import React,{Component} from 'react'

import './hello.css'
import './hello.scss'

export default class Hello extends Component{
    render(){
        return (
            <div>
                {/*这是注释*/}
                <h1>你好世界地方地方大幅度分</h1>
                <br/>
                <img/>
            </div>
        )
    }
}