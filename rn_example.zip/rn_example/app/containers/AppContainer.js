
import React, {Component} from 'react';
import {
    AppRegistry,
    StyleSheet,
    Text,
    Image,
    View,
    Navigator
} from 'react-native';

import HomeContainer from './HomeContainer.js'

export default class AppContainer extends Component {
    constructor(props) {
        super(props);
        this.state = {
        }
    }
    render() {
        return (
            <View style={styles.container}>
                <Navigator
                    // 初始化数据
                    initialRoute={{params:{name:'首页',age:12},component:HomeContainer}}
                    // 定义切换页面时候的过度效果，配置手势动画
                    configureScene={(route) => {
                        {/*if (route.sceneConfig) {*/}
                            {/*let res=route.sceneConfig;*/}
                            {/*res.gestures=null;*/}
                            {/*return res;*/}
                            {/*//return route.sceneConfig;*/}
                        {/*}*/}
                        return Navigator.SceneConfigs.PushFromRight;
                    }}
                    // 渲染页面
                    renderScene={(route, navigator) =>{
                        // 不能写死
                        let DefaultComponent=route.component;
                        return <DefaultComponent {...route.params} navigator={navigator}/>
                    }
                    }
                />
            </View>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: 'pink',
    }
});

