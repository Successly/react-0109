
import React, {Component} from 'react';
import {
    AppRegistry,
    StyleSheet,
    Text,
    Image,
    View,
    Navigator
} from 'react-native';

import MovieListContainer from './MovieListContainer.js'

export default class HomeContainer extends Component {
    constructor(props) {
        super(props);
        this.state = {
        }
    }
    render() {
        return (
            <View style={styles.container}>
                <View style={styles.header}>
                    <Text>{this.props.name}</Text>
                </View>
                <Image style={styles.image} source={require('../images/demo.jpg')}/>
                <View style={styles.menu}>
                    <Text
                          onPress={()=>this.props.navigator.push({
                              sceneConfig: Navigator.SceneConfigs.FloatFromRight,
                              component: MovieListContainer,
                              params:{
                                  name: '电影列表',
                                  movieType:'in_theaters'
                              }
                          })}
                    >
                        正在热映
                    </Text>
                    <Text
                        onPress={()=>this.props.navigator.push({
                            sceneConfig: Navigator.SceneConfigs.FloatFromRight,
                            component: MovieListContainer,
                            params:{
                                name: '电影列表',
                                movieType:'coming_soon'
                            }
                        })}
                    >
                        即将上映
                    </Text>
                    <Text
                        onPress={()=>this.props.navigator.push({
                            sceneConfig: Navigator.SceneConfigs.FloatFromRight,
                            component: MovieListContainer,
                            params:{
                                name: '电影列表',
                                movieType:'top250'
                            }
                        })}
                    >
                        Top250
                    </Text>
                </View>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: 'pink',
    },
    header:{
        height:40,
        backgroundColor:'deepskyblue',
        justifyContent:'center',
        alignItems:'center'
    },
    image:{
        height:200,
        width:400
    },
    menu:{
        height:40,
        backgroundColor: 'orange',
        flexDirection:'row',
        justifyContent:'space-around',
        alignItems:'center'
    }
});

