/*
 * 电影列表容器组件
 * */
import React from 'react'

export default class MovieDetailContainer extends React.Component {
    constructor(props) {
        super(props)
        this.state = {

        }
    }

    render() {
        return (
           <div>
               这是电影列表容器组件
           </div>
        );
    }
}

